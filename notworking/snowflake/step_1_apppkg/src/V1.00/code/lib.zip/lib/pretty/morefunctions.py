def pretty_func():
    return "Pretty Function from \lib\pretty"

if __name__ == '__main__':
    print(pretty_func())