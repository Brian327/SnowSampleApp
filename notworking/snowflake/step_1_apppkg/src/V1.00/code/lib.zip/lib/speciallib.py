
def custom_func():
    return "Custom Function from \lib"

if __name__ == '__main__':
    print(custom_func())